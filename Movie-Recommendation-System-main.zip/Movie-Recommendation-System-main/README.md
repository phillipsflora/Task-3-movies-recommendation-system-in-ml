# Movie-Recommendation-System

This project is being conducted as part of an internship program in Machine Learning provided by Bharat Intern.

In this project, I have used Streamlit for the frontend, and for model training, I have used Jupyter Notebook. 
The trained model was dumped/stored using pickle.

[Demo](https://github.com/rachit-singhal12/Movie-Recommendation-System/assets/88622017/24af43d2-ecf3-4103-bb73-b576f427bdde)
